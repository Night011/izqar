# BAF Fraud Detection — Research Progress

Worktree: `C:\Users\a\Documents\IZQAR-BAF`, branch `feat/baf-research` (from `origin/main` = b6c8c5b).

## Audit (2026-11-18)

- Trainer `backend/scripts/train_baf.py`: whitelist 15 numerics + 5 categoricals; months split — train [<penultimate-1], validation = penultimate month, test = last month (final; evaluated only in `final` mode; `experiment` mode omits test metrics). Sentinel -1 → NaN for 4 features. XGBoost(max_depth=4, lr=.06, n=180, spw=(neg/pos)*multiplier) + LogisticRegression baseline with liblinear.
- Data: `sgpjesus/bank-account-fraud-dataset-neurips-2022` (Kaggle, 558MB; Base.csv 213MB) — not stored in repo. Download in progress to `backend/data/baf/` (gitignored).
- Confirmed metrics on disk `baf_base_v1_portable.metrics.json`:
  - validation: PR-AUC 0.163963, ROC 0.8854, F1 0.2301, FP/10k 99.9 (threshold 0.9142)
  - test (previously used): PR-AUC 0.199692, ROC 0.8913, F1 0.241141, FP/10k 75.5 — matches historical orienteers. Test is a historical benchmark, NOT an independent confirmation.
- Prior candidates (validation-only, threshold budget 100 FP/10k): weight075 0.164185, recall 0.162608, weight075+early_stop 0.165998 — all within noise of baseline 0.163963. No wins yet; class-weight tweaks insufficient.
- Leakage exclusions documented in artifact: fraud_bool, month, device_fraud_count, days_since_request, credit_risk_score, unverified aggregates.
- Plan: engineered application-time features + month-expanding research folds (temporal, like IEEE) + XGBoost/LightGBM/CatBoost; internal folds drive selection; previously used test not touched for tuning.

## IEEE-CIS tech debt (carried forward)

- Fold 3 FP/10k = 106.9 vs budget 100; test FP/10k = 94.0 (129.6 for ieee_final_v2).
- IEEE results on the previously used test are not independent confirmation.
- Production inference of the IEEE candidate requires extra verification before any deploy.
- GitHub Actions blocked by account billing lock (all branches, 2–4s, zero steps); 144 local tests pass.
- Revert note: to roll back the IBM+IEEE merge use targeted `git revert` on the specific merge commit — never reset main to 0d2e9ea (would lose both agents' work).

## Stage 2 — error analysis (v1, train months [0..4], valid month 5)

- Metrics (00th-pct threshold): PR-AUC 0.167 (fold-5), F1 0.246 at 73 FP/10k (99th pct).
- Dominant signal: housing_status_BA (~0.49 mean |SHAP|, 0.32 importance) — 4.1% fraud rate segment with 770/873 FPs; device_os=windows (0.42), phone_home_valid, has_other_cards, keep_alive_session, name_email_similarity, income, prev_address_months_count missing indicator.
- FN concentration: employment_status CA/CB/CF (FN share 0.75/0.95/1.0), housing_status BC/BE (0.93/1.0), device_os linux/macintosh (0.94/0.76). Frauds hide in these segments; FPs concentrate in BA/windows/free-email segments — inherent imbalance trade-off.
- Stability: same top features across months; name_email_similarity weaker but stable mid-rank.
- Not promoted: v2 engineered features (no fold gain). Velocity aggregates excluded from candidates (Stage 4).

## Stage 3 — in flight

- Kaggle GPU kernel `hoogle57/izqar-baf-algorithms-gpu-v1` (rev 97ebd1b): XGBoost vs LightGBM vs CatBoost × v1/v2 on identical folds. Status: QUEUED.
- Controlled local arm: v1 with max_depth=6 (only change vs v1) — running (PID 5244).
- max_depth=6 REJECTED: mean PR-AUC 0.1517 (0.1361/0.1551/0.1639) vs v1 0.1565.
- lr=0.03, 800 trees, early stop 60 — REJECTED: mean PR-AUC 0.1558 (0.1404/0.1593/0.1678) vs v1 0.1565. baseline plateau persists.
- Threshold drift across months: 0.939 (m3) → 0.935 (m4) → 0.913 (m5) with fraud-rate 0.92%→1.18%; fixed threshold not stable — budget-aware per-month recalibration is appropriate.
- Kaggle kernel QUEUED ~50+ min without diagnostics; local fallback: isolated venv (temp) with lightgbm+catboost for identical folds.

## Stage 3 experiment ledger (identical folds, months 3/4/5, 1500-400 iters)

| Config | Mean PR-AUC | Folds | Verdict |
|---|---|---|---|
| xgboost v1 (280-config, depth 4) | 0.1554/0.1565 | 0.140/0.158/0.168 | reference best so far |
| xgboost v2 | 0.1538/0.1549 | 0.139/0.156/0.166 | rejected (-0.002) |
| xgboost max_depth=6 | 0.1517 | 0.136/0.155/0.164 | rejected |
| xgboost lr=0.03, 800 trees | 0.1558 | 0.140/0.159/0.168 | rejected (~noise) |
| catboost (OHE) v1 / v2 | 0.1572 / 0.1578 | ~0.144/0.161/0.167 | parity with XGB (+0.002) |
| catboost native (no OHE) v1 / v2 | 0.1556 / 0.1562 | 0.143/0.162/0.167 | parity (no gain vs OHE) |
| lightgbm v1/v2 (SPW or is_unbalance) | 0.052 | 0.048/0.052/0.057 | BROKEN arm — early-stops at iter 1; even tuned (is_unbalance, depth=-1, leaves=31) PR-AUC 0.053. Dropped, documented as LightGBM failing on this workload/config, not on LightGBM per se |
| velocity headroom (v2 + 7 aggs) | 0.1737 | 0.154/0.178/0.189 | NOT eligible (Stage 4) |
| XGB+CatBoost rank-average ensemble | 0.1579 (v1) / 0.1571 (v2) | 0.143/0.163/0.167 | parity — NOT adopted (no gain ≥ error) |
| **Decision**: no admissible configuration beats XGBoost-v1 on internal folds. Ceiling ≈ 0.156–0.158 mean PR-AUC across the best three arms. Baseline model stands. |

- 2026-11-18 (late): final verdict recorded. BAF experimental endpoint `/api/v1/model/baf-candidate` added (read-only; metrics of research folds; 404 when absent). 147 tests passed. Ensemble NOT adopted (P@100 flat 0.5 vs XGB 0.46/0.50/0.50, within noise).
- Recommendation: ship nothing new; document ceiling. Any further gains would need the verified streaming velocity pipeline (excluded by Stage 4) or stronger raw signals.

## Stage 7 — corrected evaluation protocol (validity fix)

Problem: `threshold_analysis(fold_valid.fraud_bool, scores, 100)` chose the operating point on the same fold it reported, so FP/10k ≈ 99.6 was guaranteed by construction. Same fold also drove early stopping.

Protocol (`backend/scripts/baf_protocol.py`, `--protocol calibrated`): for external month *m*, fit on months < *m*−1, choose **both** the round count and the threshold on month *m*−1, score month *m* once with both frozen. `--protocol infold` reproduces the old layout and is labelled optimistic in the artifact. Months 6/7 never enter selection. Regression tests: `backend/tests/test_baf_protocol.py` (8 tests; **155 backend tests pass**; CI remains blocked by the GitHub Actions billing lock).

XGBoost v1, calibrated (`docs/baf_calibrated_v1.metrics.json`):

| External fold | Train / cal | PR-AUC | ROC | P@100 | P@1000 | Recall | F1 | FP/10k (frozen) | FP/10k on cal | Rounds |
|---|---|---|---|---|---|---|---|---|---|---|
| m3 | m0–1 / m2 | 0.137190 | 0.9043 | 0.45 | 0.226 | 0.3621 | 0.2016 | **205.7** | 99.87 | 304 |
| m4 | m0–2 / m3 | 0.156176 | 0.8998 | 0.46 | 0.260 | 0.2417 | 0.2190 | **109.9** | 99.18 | 264 |
| m5 | m0–3 / m4 | 0.166224 | 0.8853 | 0.48 | 0.298 | 0.1906 | 0.2350 | 51.0 | 99.77 | 228 |
| mean | | 0.153197 | 0.8965 | 0.463 | 0.261 | 0.2648 | 0.2185 | **122.2** | 99.6 | |

Comparison with the in-fold protocol (old, optimistic): mean PR-AUC 0.1565, F1 0.2266, FP/10k 99.6.

- Ranking quality is unchanged: P@100 0.45/0.46/0.48 and P@1000 0.226/0.260/0.298 match the old 0.46/0.50/0.50 and 0.230/0.257/0.291 within noise. The old optimism was **entirely in the operating point**, not in the model.
- With a genuinely pre-registered threshold the 100 FP/10k budget is breached on 2 of 3 folds (205.7, 109.9) while calibration itself is always ≈99.7 — the score distribution shifts between months (fraud rate 0.92%→1.18%).
- Post-hoc recall at 50/75/100 FP/10k on the external folds (diagnostic; recalibrating per period needs labels): 0.159/0.197/0.233 · 0.168/0.196/0.236 · 0.190/0.238/0.266.
- Fold m3 now trains on 260k rows instead of 397k (the extra month became calibration), so its PR-AUC is slightly lower; this is the honest cost of the protocol.

## Stage 7b — algorithm comparison under the corrected protocol (run B)

`docs/baf_calibrated_algos_v1.metrics.json` — 6 arms × 3 calibrated folds, identical periods, identical selection rule (rounds and threshold on the calibration month only), v1 features.

| Arm | PR-AUC (f3/f4/f5) | Mean PR-AUC | Mean F1 | FP/10k frozen (f3/f4/f5) | Recall@100 post-hoc | P@1000 (f3/f4/f5) | Rounds | Fit s (f5) |
|---|---|---|---|---|---|---|---|---|
| catboost (OHE) | .1392/.1623/.1657 | **0.1558** | 0.2186 | 212.9/106.9/52.5 | .239/.233/.262 | .223/.253/.291 | 350/275/350 | 52 |
| ensemble xgb+cb_native | .1399/.1598/.1670 | **0.1556** | **0.2258** | **98.2/95.6/96.1** | .237/.233/.264 | .230/.260/.297 | 300/400 · 250/375 · 200/400 | 180 |
| catboost_native | .1394/.1594/.1648 | 0.1545 | 0.2213 | 210.7/104.8/50.5 | .236/.234/.262 | .230/.253/.288 | 400/375/400 | 177 |
| lightgbm_reg | .1365/.1582/.1677 | 0.1541 | 0.2195 | 202.5/107.4/49.6 | .242/.238/.261 | .222/.261/.289 | 750/800/800 | 29 |
| xgboost v1 | .1372/.1565/.1652 | 0.1529 | 0.2199 | 204.3/109.9/51.4 | .233/.233/.264 | .226/.262/.297 | 300/250/200 | 33 |
| lightgbm (unweighted) | .1312/.1568/.1608 | 0.1496 | 0.2163 | 207.2/108.0/51.8 | .241/.238/.265 | .218/.251/.286 | 250/200/150 | 20 |

Conclusions:

- **No arm separates on ranking.** PR-AUC spans 0.1496–0.1558 with per-fold spread ≈0.01; P@1000 and post-hoc recall@100 are within ±0.01 for all six. Algorithm choice is not the bottleneck; the v1 feature signal is. This is a measured plateau over 6 configurations, 3 folds and one dataset variant — not a proven ceiling.
- **The old optimism was the operating point, not the model.** Five arms breach 100 FP/10k on folds m3/m4 (200–213 / 105–110) while their calibration months sit at ≈99.7. A probability threshold fitted on one month does not transport to the next (fraud rate 0.92%→1.18%).
- **Ensemble is the only arm inside the budget on all folds (98.2/95.6/96.1).** Cause: rank averaging makes the score distribution uniform, so the calibration threshold is effectively a within-batch quantile. That is *not* available for single-request scoring without a rolling reference window — so its operating-point advantage is batch-dependent and not adopted.
- **LightGBM is not broken.** Root cause of the old 0.052: `eval_metric='aucpr'` is an XGBoost name, LightGBM ignored it and monitored weighted `binary_logloss`, which rises by construction under `scale_pos_weight`; early stopping kept round 1 and LightGBM discarded every later tree (`current_iteration() == 1`). With explicit round selection on calibration PR-AUC, LightGBM reaches 0.1496 (unweighted) and 0.1541 (regularised), i.e. parity.

Verdict: research stage BAF closed on the current feature contract. No configuration beats the baseline beyond noise; nothing is promoted to production, and the production artifact is untouched. Remaining headroom needs new admissible signals (a verified streaming velocity pipeline), not more tuning.

Reproduction (local, `backend/data/baf/Base.csv`, venv with xgboost 3.4.1 / lightgbm 4.7.0 / catboost 1.2.10 / sklearn 1.9.1):

```powershell
python backend/scripts/train_baf.py --data backend/data/baf/Base.csv --output models/experiments/baf_calibrated_v1.metrics.json --mode research --protocol calibrated --feature-set v1 --estimators 400 --early-stopping-rounds 40
python backend/scripts/research_baf_algorithms.py --data backend/data/baf/Base.csv --output models/experiments/baf_calibrated_algos_v1.metrics.json --algos xgboost catboost catboost_native lightgbm lightgbm_reg ensemble --feature-sets v1 --max-rounds 400 --device cpu
```

Each fold report carries train/calibration/external months, row counts, per-period row-index sha256, best iteration, fit seconds, selected threshold, calibration sweep and full confusion matrix.

## Stage 9 — velocity admissibility, fixed-capacity operating point, pre-deployment refit

Three questions were still open after Stage 8. All three are now measured on the same calibrated folds (train < calibration < external, threshold/rounds frozen; `docs/baf_policy_velocity_v1.metrics.json`).

**1. Are the seven blocked "velocity" columns admissible?** Yes in principle. The official BAF datasheet (`feedzai/bank-account-fraud/documents/datasheet.pdf`, p.2) defines them as trailing-window counts of *prior applications*: `zip_count_4w` = applications in the same ZIP in the last 4 weeks; `velocity_6h`/`24h`/`4w` = average applications per hour over the last 6h/24h/4w; `bank_branch_count_8w`; `date_of_birth_distinct_emails_4w`; `device_distinct_emails_8w`. They are pre-decision business aggregates, not outcomes, so they carry no label leakage. What is still missing is not permission but plumbing: IZQAR must compute the same seven counters over its own application stream (7 rolling-window aggregations keyed by ZIP / branch / DOB / device).

**2. Does that headroom survive the honest protocol?** Yes, and it is the only arm that does.

| Arm | Mean PR-AUC | PR-AUC m3/m4/m5 | Recall @capacity m3/m4/m5 | FP/10k @capacity |
|---|---|---|---|---|
| xgboost v1 | 0.1529 | 0.1372/0.1565/0.1652 | 0.229/0.231/0.260 | 98/96/96 |
| catboost v1 | 0.1558 | 0.1392/0.1623/0.1657 | 0.237/0.227/0.259 | 98/96/96 |
| **xgboost v1v** | **0.1708** (+0.0179) | 0.1501/0.1752/0.1870 | 0.251/0.253/0.279 (+0.022/+0.022/+0.019) | 97/94/95 |
| **catboost v1v** | **0.1732** (+0.0174) | 0.1573/0.1731/0.1891 | 0.254/0.247/0.279 | 98/95/97 |

The gain holds on every fold (+0.011…+0.023) and is ~+10% relative recall at the same false-alert budget. CatBoost's +0.002 lead over XGBoost is inside fold noise and costs 2–3× fit time; XGBoost keeps the tie-break. The earlier 0.1737 estimate (optimistic in-fold threshold) was not inflated by the feature class — it reproduces at 0.1708 under the corrected protocol.

**3. Can the 100 FP/10k budget be met without labels?** Yes, by freezing an alert *rate* instead of a probability. The threshold chosen on the calibration month is translated into the share of that batch it flags (~1.19–1.26%), and the same top share is flagged on the external month. This uses only the score distribution, never external labels, and is the operational equivalent of ranking today's applications and reviewing the top q%. Measured: FP/10k 94–98 on all folds (a frozen probability threshold gave 51–233), and recall lands within **0.0007–0.0069** of the oracle threshold that *is* allowed to fit the external labels at the same budget. On m5 it also gains recall (0.260 vs 0.192) because it spends the budget instead of under-alerting. Cost: serving needs a rolling window of recent scores, since the API scores one request at a time today.

**4. Pre-deployment refit.** Refitting on train+calibration with the round count frozen (calibration then contributes rows, not choices) is worth +0.0017 (XGB) / +0.0019 (Cat) mean PR-AUC, largest on the data-starved m3 fold (+0.0028/+0.0020). Free improvement, no new features, no external data.

Decision: nothing is promoted to production. `v1v` becomes the documented best candidate and the reference for future work, conditional on the seven streaming counters; the capacity policy becomes the recommended serving rule, conditional on a rolling score window. The production artifact (`baf_base_v1_portable`) and its fixed-threshold contract are untouched and remain the rollback point.

Reproduction:

```powershell
python backend/scripts/research_baf_algorithms.py --data backend/data/baf/Base.csv --output models/experiments/baf_policy_velocity_v1.metrics.json --algos xgboost catboost --feature-sets v1 v1v --max-rounds 400 --refit-on-calibration
python backend/scripts/research_baf_ceiling.py --data backend/data/baf/Base.csv --learning-curve
```

The committed copy of the first artifact drops the per-fold calibration `curve`/`sweep` arrays (457 KB → 81 KB); every reported metric is retained and both are regenerated by the commands above.

## Stage 10 — is the ceiling drift or signal? (`research_baf_ceiling.py`)

Each research month was split in half at random: fit on one half, score the other. This removes month-to-month drift entirely (same period, same batch) and leaves only the within-period signal. Fixed 300 rounds, no early stopping, no threshold; PR-AUC and P@1000 are threshold-free.

| External month | Train rows (half) | Same-month PR-AUC v1 | v1v | Cross-month PR-AUC v1v |
|---|---|---|---|---|
| m3 | 75,468 | 0.1185 | 0.1365 | 0.1501 |
| m4 | 63,845 | 0.1374 | 0.1449 | 0.1752 |
| m5 | 59,661 | 0.1494 | 0.1617 | 0.1870 |

Same-month is **worse** than cross-month on every month, by 0.014–0.030, despite zero drift. So the binding constraint is not drift; it is training volume. Confirmed by a learning curve on the m4 fold (v1v, train region subsampled, 300 rounds):

| Train rows | PR-AUC on m4 |
|---|---|
| 99,259 (25%) | 0.1384 |
| 198,519 (50%) | 0.1718 |
| 397,039 (100%) | 0.1755 |

The curve is steep up to ~200k rows and then flattens (+0.004 for the second doubling). The full-history models (260k–600k rows) therefore sit within ~0.004 of the practical plateau, and m3's weakness is a volume effect (two months of history) rather than a drift or tuning defect. Practical consequence: further tuning on this dataset has little room; the two levers that did move the number are the seven velocity columns (+0.018 PR-AUC, available once the streaming counters exist) and, marginally, the pre-deployment refit.

## Stage 11 — official benchmark reproduction (`research_baf_official.py`)

Feedzai's `notebooks/empirical_results.ipynb`: months 0–5 train, 6–7 test, **every column except `fraud_bool`**, LabelEncoder cats (we use pandas category dtype so unseen levels do not raise), LightGBM sampled from `lightgbm_hyperparameter_space.yaml`, operating point at FPR<5% (≈500 FP/10k) chosen on the test labels. 12 trials instead of 100, `n_estimators` capped at 600.

| Variant (identical folds, months 6–7) | PR-AUC | recall@5%FPR | recall@100 FP/10k |
|---|---|---|---|
| official (all columns) | 0.1968 | 0.553 | 0.258 |
| minus `month` | 0.1958 | — | 0.259 |
| admissible (v1+velocity, no `month`/`days_since_request`/`device_fraud_count`/`credit_risk_score`) | 0.1892 | — | 0.242 |

Ablation evidence per excluded column (data audit over 1M rows + datasheet):

| Column | Evidence | Decision |
|---|---|---|
| `device_fraud_count` | **constant 0 in Base** (nunique=1); by definition "number of fraudulent applications with used device", i.e. label-derived | correctly excluded, and it carries no information here |
| `days_since_request` | datasheet: days since the application was made (0–79), median 0.015 — post-application | excluded, not known at decision time |
| `month` | time index; the model would read the fraud-rate trend | excluded (measured cost: −0.0010 PR-AUC) |
| `credit_risk_score` | datasheet: the *bank's* internal application risk score, −191…389, 1.4% negative | excluded on availability (IZQAR is not the issuing bank), not on leakage; measured cost −0.0066 |

The research contract loses 0.0076 PR-AUC in total, and none of it is a leak we could legitimately re-add.

## Stage 12 — tuning, encodings, preprocessing, ensembles

Search: Optuna TPE, objective = PR-AUC on month 2 with the model fitted on months 0–1 (month 2 is never an external fold). 30 LightGBM trials, 8 CatBoost native trials. Best config frozen, then evaluated unchanged on the folds.

| arm (v1v = v1 + 7 velocity columns) | mean PR-AUC | recall@capacity m3/4/5 | FP/10k |
|---|---|---|---|
| xgboost v1 (old baseline) | 0.1529 | 0.229/0.231/0.260 | 98/96/96 |
| catboost v1 | 0.1558 | 0.237/0.227/0.259 | 98/96/96 |
| xgboost v1v | 0.1708 | 0.251/0.253/0.279 | 97/94/95 |
| lightgbm v1v tuned (OHE) | 0.1712 | 0.264/0.242/0.272 | 97/97/96 |
| lightgbm v1v tuned, native cats + raw NaN | 0.1710 | 0.261/0.247/0.271 | 98/95/96 |
| lightgbm v1v tuned, balcon negatives = missing | 0.1712 | 0.256/0.247/0.266 | 97/96/97 |
| catboost v1v (Run B config) | 0.1732 | 0.254/0.247/0.279 | 98/95/97 |
| **catboost native v1v tuned** | **0.1739** | 0.255/0.249/0.282 | 97/95/96 |
| v1x velocity ratios (xgb / lgbm) | 0.1696 / 0.1691 | 0.253/0.240/0.279 | 97/96/96 |
| ensemble xgb+cat_native | 0.1750 | 0.257/0.249/0.281 | 98/94/96 |
| ensemble lgbm_native+cat_native | 0.1755 | 0.260/0.249/0.275 | 98/94/96 |
| **ensemble xgb+lgbm_native+cat_native** | **0.1759** | 0.262/0.258/0.281 | 97/95/96 |

Findings:

1. **Hyperparameter search does not transfer.** LightGBM lifted its selection month 0.1322→0.1387 (+0.0066) and CatBoost 0.1343→0.1360 (+0.0017), but on the folds tuned LightGBM is 0.1712 vs 0.1708 for untuned XGBoost, and tuned CatBoost 0.1739 vs 0.1732 for its untuned twin. That selection gain was month-2 noise.
2. **Encoding and missing-value handling are not the bottleneck.** Native categoricals with raw NaN (the published LightGBM recipe) score 0.1710 vs 0.1712 for one-hot + median imputation; masking `intended_balcon_amount` negatives and `device_distinct_emails_8w` = −1 as missing changes nothing (+0.0002). Both are still the *correct* reading of the datasheet and are now the default in the research harness.
3. **Velocity ratio interactions do not help** (−0.002 on both libraries). The absolute counts already carry the signal.
4. **Only the ensemble moves the mean**, 0.1739 → 0.1759 (+0.0020, driven by m4/m5 and slightly negative on m3), computed from out-of-fold external scores only, with no weight fitted anywhere.

### Stage 12b — extra members, seed repeats, fitted blend weights

| variant | PR-AUC m3/m4/m5 | mean | Δ vs 0.1732 | recall@capacity |
|---|---|---|---|---|
| lightgbm native, class-weighted | 0.1526/0.1765/0.1892 | 0.1727 | −0.0005 | .257/.241/.279 |
| ensemble 4 arms (xgb, lgbm, lgbm_w, cat) | 0.1574/0.1800/0.1928 | 0.1767 | +0.0035 | .256/.253/.283 |
| ensemble 5 arms (+ catboost one-hot) | 0.1582/0.1798/0.1926 | **0.1769** | **+0.0037** | .259/.250/.282 |
| ensemble 6 arms (+ lightgbm one-hot) | — | 0.1766 | +0.0034 | — |
| ensemble 3 models × 2 seeds | 0.1563/0.1792/0.1919 | 0.1758 | +0.0026 | — |
| ensemble with weights fitted on calibration | — | 0.1753 | +0.0021 | — |

Negative results, all measured: class weighting helps LightGBM alone (+0.0017 over unweighted) but not the blend; repeating seeds of the same algorithm adds ≤0.0009 and dilutes the blend; blend weights fitted on a calibration month (≈660 frauds) are worse than uniform; the one-hot CatBoost and weighted LightGBM members help only as diversity. The blend gain is +0.0037 and lands entirely in m4/m5 — m3 stays at the single-model level.

### Stage 12c — training-side levers, all flat

| lever | arm | PR-AUC m3/m4/m5 | mean | vs reference |
|---|---|---|---|---|
| round cap 400 → 1000 | catboost native | 0.1583/0.1743/0.1882 | 0.1736 | −0.0003 |
| round cap 400 → 1000 | xgboost | identical to 400 (still picks 175) | 0.1708 | 0 |
| round cap 400 → 1000 | lightgbm native | identical to 400 (picks 275–325) | 0.1710 | 0 |
| rounds chosen by recall@budget, not PR-AUC | catboost native | 0.1594/0.1736/0.1881 | 0.1737 | −0.0002 |
| recency weights (half-life 2 months) | lightgbm native | 0.1466/0.1712/0.1900 | 0.1692 | −0.0018 |
| blend + budget-selected CatBoost member | 6 arms | — | 0.1769 | +0.0001 (noise) |
| blend + recency-weighted member | 6 arms | — | 0.1764 | −0.0005 |

The 400-round cap bound only CatBoost, and lifting it does not help; the served operating point is not round-limited either (budget-based selection is identical within noise); recency weighting hurts, which is consistent with the Stage 10 finding that month drift is not the limiting factor. Every training-side lever measured so far lands inside ±0.002 of the plateau, while the seven velocity columns were worth +0.018.

### Stage 12d — heterogeneous boosting variants

| member | PR-AUC m3/m4/m5 | mean | note |
|---|---|---|---|
| LightGBM `dart` | — | 0.1658 | weakest alone (−0.0052), no blend gain |
| CatBoost `Lossguide` (max_leaves 31) | 0.1714/0.1728/0.1698 | 0.1714 | weaker alone, but adds diversity |
| **6-arm blend (5 arms + Lossguide)** | **0.1589/0.1797/0.1936** | **0.1774** | new best, FP/10k 98/95/95 |
| 6-arm blend with `dart` instead | — | 0.1758 | no gain |
| 7-arm blend (both) | — | 0.1764 | duplicates dilute |

Diversity pays only with a different *tree-growth policy* (Lossguide: +0.0005), not a different *boosting scheme* (dart: −0.0016).




Trade-off at the same folds (post-hoc, threshold-free view; working budget stays 100):

| arm | recall@50 | @100 | @200 | @500 |
|---|---|---|---|---|
| xgboost v1 | 0.172 | 0.244 | 0.318 | 0.494 |
| xgboost v1v | 0.184 | 0.266 | 0.353 | 0.529 |
| catboost native v1v tuned | 0.180 | 0.267 | 0.372 | 0.554 |
| ensemble xgb+lgbm+cat | 0.182 | 0.271 | 0.377 | 0.559 |

The capacity policy holds the budget at 94–98 FP/10k on every fold and every arm while landing 0.001–0.007 recall below the oracle threshold at the same budget.

## Where the remaining error can come from

Five algorithm/encoding variants sit in 0.171–0.174, tuning does not transfer, interactions hurt, the learning curve is flat above ~400k rows, and the only thing that ever moved the number was seven new aggregate columns (+0.018). The limit is **feature coverage**, not model capacity, not tuning, not drift.

| # | Missing information | Evidence it should transfer | IZQAR feasibility |
|---|---|---|---|
| 1 | Trailing counts of *prior confirmed frauds* per device/email/phone/address (6h/24h/4w/8w) | `device_fraud_count` is exactly this signal in BAF and is constant 0 here, so Base cannot price it; in production it is the strongest account-opening predictor | high — the review/investigation workflow already produces confirmed outcomes; needs a label-lag-aware rolling counter |
| 2 | Wider entity keys and cross-entity ratios (IP, phone, employer; distinct accounts per device × distinct devices per email) | BAF's four entity keys are already its strongest aggregate columns; the same construction over more keys is the natural extension | high — event store plus precomputed counters at application time |
| 3 | KYC / device-intelligence vendor outputs (document liveness, IP reputation, emulator flags) | absent from BAF, so no fold can price it | medium — integration and contract work |
| 4 | Post-application outcomes (chargebacks) | unavailable at decision time; usable only to enrich labels | low for scoring |

Adoption rule for any step: offline replay of a historical application stream, then a rerun of the same three folds, requiring ≥+0.01 mean PR-AUC with FP/10k ≤100 on **every** fold. Anything smaller is inside fold noise and does not justify a production change.








## Log

- 2026-11-19d: boosting-variant members. CatBoost Lossguide joins the blend as a sixth member and sets a new best: mean PR-AUC 0.1774, recall@capacity .262/.256/.279, FP/10k 98/95/95 (+0.0042 vs 0.1732). LightGBM dart is weaker alone (0.1658) and does not help. Recorded the tuned and variant parameter sets under docs/baf_params_*.json.
- 2026-11-19c: training-side levers tested and all flat: round cap 400→1000 (CatBoost −0.0003, others unaffected), rounds selected by recall@budget instead of PR-AUC (−0.0002), recency weights (−0.0018), and their blend members (±0.0005). Best stays the 5-arm rank ensemble at 0.1769 mean PR-AUC.
- 2026-11-19b: extra ensemble members tested. Best measured: 5-arm rank ensemble (xgboost, lightgbm native, class-weighted lightgbm native, catboost native, catboost one-hot) at mean PR-AUC 0.1769, recall@100 FP/10k 0.264, FP/10k 97/93/96 (+0.0037 vs 0.1732). Seed repeats, fitted blend weights and a sixth member are all flat or worse.
- 2026-11-19: official Feedzai benchmark reproduced on months 6–7 (PR-AUC 0.1968, recall@5%FPR 0.553); the admissible contract costs −0.0076 PR-AUC. 30+8 Optuna trials on month 2 do not transfer to the folds. Native vs one-hot categoricals, raw NaN vs imputation, balcon/device_email sentinels, and velocity ratio interactions are all inside noise. Best measured: catboost native v1v 0.1739, 3-model rank ensemble 0.1759 (+0.0027 vs 0.1732), recall@100 0.271.
- 2026-11-18: Audit done; Base.csv downloaded locally (1,000,000 rows; 1.103% fraud; months 0–7; train [0–5], valid 6, test 7 — test never used for tuning).
- Research folds (train region only, expanding: valid months 3/4/5; threshold from fold valid, FP/10k budget 100; 400 trees, early stop 40):

| Config | Fold3 (0.141) PR-AUC | Fold4 | Fold5 | Mean PR-AUC | Mean F1 | Mean FP/10k | P@100 (folds) | P@1000 (folds) |
|---|---|---|---|---|---|---|---|---|
| v1 (20 feat, XGB 180-config) | 0.141364 (rows 397k) | 0.160951 (548k) | 0.167087 (676k) | 0.156467 | 0.2266 | 99.6 | 0.46/0.50/0.50 | 0.230/0.257/0.291 |
| v2 (+12 engineered) | 0.138503 | 0.159649 | 0.166637 | 0.154930 | 0.2298 | 99.1 | 0.49/0.46/0.48 | 0.225/0.262/0.282 |
| velocity (v2 + 7 velocity aggs) | 0.154405 | 0.177726 | 0.189083 | **0.173738** | 0.2426 | 99.5 | 0.55/0.56/0.59 | 0.235/0.264/0.310 |

- v2 engineered features: NO measurable gain (mean PR-AUC −0.0015). Velocity aggregates: +0.0173 mean PR-AUC, P@100 +0.10 — meaningful headroom, but NOT deployable without a verified streaming aggregation pipeline (application-time availability unverified). Decision: candidate keeps v1 feature contract + tuning; velocity documented as blocked enhancement.
- Kaggle GPU kernel `hoogle57/izqar-baf-algorithms-gpu-v1` pushed (pinned 97ebd1b): XGBoost vs LightGBM vs CatBoost × v1/v2 on identical folds. Pending.
