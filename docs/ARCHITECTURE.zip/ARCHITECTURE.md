# Архитектура IZQAR v0.1

## 1. Независимые потоки данных

### Демонстрационный поток

```
HTML / React UI
    └─POST /api/v1/demo/simulate или /transfers
          └─RiskEngine.assess(известная история + текущий перевод)
              └─SQLAlchemy → SQLite (localhost) / PostgreSQL (Docker)
              └─Объяснимые причины + risk_score, decision
    └─GET /api/v1/graph → NetworkX → Cytoscape / SVG
    └─PATCH /api/v1/transactions/{id}/review
       └─investigation_events: решение + комментарий + время
    └─GET /api/v1/investigations → очередь и карточка с ограниченной историей связанных операций
    └─POST /api/v1/investigations/{id}/comments → append-only событие
```

Каждое действие сохраняет уже **синтетическую** операцию. Анализ признаков берёт только предыдущие строки БД. Высокая связность на графе — признак для изучения, а не обвинение.

### ML-потоки (строго раздельные)

```
train_transaction.csv (+ train_identity.csv)
  └─Хронологическая сортировка / 70:15:15
     └─Pipeline: Imputer, OneHotEncoder, XGBClassifier
        └─Порог по validation (F1)
           └─Оценка на test → JSON метрики
              └─models/ieee_model.joblib
                 └─POST /api/v1/ieee/predict

PaySim CSV
  └─Хронологическая сортировка `step` / 70:15:15
     └─только pre-transaction `type`, `amount`, `oldbalanceOrg`, `oldbalanceDest`
        └─исключение target, post-event balances, account IDs и `isFlaggedFraud`
           └─models/paysim_model_v2_portable.metrics.json
              + .preprocessor.joblib + .xgboost.json
              └─POST /api/v1/paysim/predict

BAF Base.csv (заявки на открытие счёта)
  └─Предпоследний `month` validation, последний `month` final test
     └─Явный список признаков заявки; `fraud_bool` только y
        └─models/baf_base_v1_portable.metrics.json + preprocessing + XGBoost JSON
           └─POST /api/v1/baf/predict (503 при отсутствии артефакта)

IBM AML HI-Small_Trans.csv (синтетические операции с меткой отмывания)
  └─Временное разделение 70:15:15; последний период используется только в final
     └─Текущие сумма, валюты, формат, время и признак одного банка
        └─Без `Is Laundering`, счетов, банковских ID и будущей истории
           └─models/ibm_aml_hi_small_v1_portable.metrics.json + preprocessing + XGBoost JSON
              └─POST /api/v1/ibm-aml/predict (503 при отсутствии артефакта)
```

Значения скоров симулятора **не** подаются в IEEE-модель и наоборот.

`GET /api/v1/model/registry` читает только JSON-отчёты из доверенного локального каталога моделей и активных путей конфигурации. Для активной и архивной записи он показывает схему, происхождение исходного CSV, версию, метрики, SHA-256 манифеста и компонентов, а также отсутствие компонентов. Просмотр реестра не вызывает `joblib.load`; контрольная сумма подтверждает идентичность файла, но не качество модели и не безопасность неизвестного pickle.

## 2. API и безопасность MVP

- Все `/api/v1/*` эндпоинты требуют заголовок `X-API-Key`, `secrets.compare_digest`.
- CORS ограничен указанными localhost origins; публикация в интернет запрещена до отдельного аудита.
- Все `/api/v1/*` запросы с заявленным телом больше 64 KiB отклоняются до разбора JSON; некорректный `Content-Length` возвращает 400.
- Транзакции только с фиктивными счетами, максимальная сумма 100 млн KZT, идентификаторы разрешают только безопасные латинские символы.
- SQLAlchemy parameter binding защищает от типовых SQL-инъекций.
- Локальный журнал действий хранит изменение статуса и комментарий атомарно с решением. `actor_source=local_demo_api_key` указывает способ доступа, **не личность** аналитика. Старые решения до создания таблицы не имеют событий. Для реальной эксплуатации необходимы индивидуальные учётные записи аналитиков, права, защищённый неизменяемый аудит, throttling, CSRF (если появятся cookie-сессии), защищённый секрет-менеджмент и Alembic.

## 3. Корректность ML

- IEEE-CIS содержит онлайн-платёжные признаки и не содержит переводов `account A → account B`, достаточных для достоверного графового расследования.
- `TransactionDT` используется только для **разбиения**, не включён в ML-признаки. Identity merge проверяется `one_to_one` по `TransactionID`.
- PaySim `isFraud` используется исключительно как y. `isFlaggedFraud`, новые балансы, ID счетов и будущая история физически отсутствуют в feature contract.
- Обе модели сохраняют baseline и XGBoost метрики раздельно. Скор называется uncalibrated ML score, пока отдельная калибровка не доказана.
- PaySim v1/v2 архивы `joblib` сохранены, но их XGBoost pickle не является переносимым между Kaggle Linux и Windows. API принимает также формат v3: отчёт-манифест, обученный preprocessing и модель XGBoost JSON. Источник установки должен быть доверенным; загрузка preprocessing через `joblib` выполняет Python-десериализацию.
- Любой вывод о качестве модели должен ссылаться на `models/ieee_model.metrics.json`, **не** на примеры из симулятора.
- Отдельный графовый датасет (например, IBM AML, с соблюдением лицензии и воспроизводимым ETL) — следующий этап.

## 4. Как не сломать разработку

- Не меняй эндпоинты или JSON-контракты без обновления TypeScript типов, HTML-демо, Pytest и README.
- Старайся делать небольшие коммиты Conventional Commits: `feat:`, `fix:`, `test:`, `docs:`.
- Не пиши в README метрики, которых не было в реально запущенных экспериментах.
